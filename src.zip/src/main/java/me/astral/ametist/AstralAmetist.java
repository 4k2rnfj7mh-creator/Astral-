
package me.astral.ametist;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Random;

public class AstralAmetist extends JavaPlugin implements Listener {

    private NamespacedKey key;
    private final Random random = new Random();

    @Override
    public void onEnable() {
        key = new NamespacedKey(this, "astral_ametist");
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("AstralAmetist habilitada.");
    }

    @EventHandler
    public void onInteract(PlayerInteractEntityEvent event) {
        Player player = event.getPlayer();
        Entity target = event.getRightClicked();

        ItemStack item = player.getInventory().getItemInMainHand();
        if (item.getType() != Material.AMETHYST_SHARD) return;
        if (!item.hasItemMeta()) return;

        ItemMeta meta = item.getItemMeta();
        if (!meta.hasDisplayName()) return;
        if (!meta.getDisplayName().equalsIgnoreCase("astral ametist")) return;

        meta.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);

        event.setCancelled(true);

        int roll = random.nextInt(100);

        if (roll < 40) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 20 * 10, 1));
        } else if (roll < 70) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 15, 1));
        } else if (roll < 90) {
            target.getWorld().strikeLightningEffect(target.getLocation());
        } else {
            player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 20 * 8, 0));
        }
    }
}
